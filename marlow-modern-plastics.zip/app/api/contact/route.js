
import nodemailer from "nodemailer";

export async function POST(req) {
  const formData = await req.formData();
  const name = formData.get("name");
  const email = formData.get("email");
  const message = formData.get("message");

  const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: process.env.GMAIL_USER,
      pass: process.env.GMAIL_PASS
    }
  });

  await transporter.sendMail({
    from: process.env.GMAIL_USER,
    to: process.env.GMAIL_USER,
    subject: "New Website Contact Form",
    text: `Name: ${name}\nEmail: ${email}\nMessage: ${message}`
  });

  return new Response("Sent", { status: 200 });
}
