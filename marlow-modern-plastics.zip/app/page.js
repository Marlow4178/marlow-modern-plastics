
export default function Home() {
  return (
    <main style={{ padding: 40 }}>
      <h1>Marlow Modern Plastics</h1>
      <p>Precision plastics manufacturing solutions.</p>
      <a href="/contact">Contact</a>
    </main>
  );
}
