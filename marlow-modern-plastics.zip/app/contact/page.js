
export default function Contact() {
  return (
    <main style={{ padding: 40 }}>
      <h1>Contact</h1>
      <form method="POST" action="/api/contact">
        <input name="name" placeholder="Name" />
        <input name="email" placeholder="Email" />
        <textarea name="message" placeholder="Message"></textarea>
        <button type="submit">Send</button>
      </form>
    </main>
  );
}
